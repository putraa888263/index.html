function showLoading() {
    document.getElementById('loading').style.display = 'block';
    document.getElementById('error-message').textContent = '';
}

function showError(message) {
    document.getElementById('loading').style.display = 'none';
    document.getElementById('error-message').textContent = message;
}

function doLogin() {
    showLoading();
    
    const username = document.login.username.value;
    const password = document.login.password.value;
    
    if (!username || !password) {
        showError('Username and password are required');
        return false;
    }
    
    return true;
}

function doVoucherLogin() {
    showLoading();
    
    const voucher = document.login.voucher.value;
    
    if (!voucher) {
        showError('Voucher code is required');
        return false;
    }
    
    return true;
}

// Auto-focus first input field
window.onload = function() {
    const inputs = document.getElementsByTagName('input');
    for (let i = 0; i < inputs.length; i++) {
        if (inputs[i].type !== 'hidden' && inputs[i].type !== 'submit') {
            inputs[i].focus();
            break;
        }
    }
};