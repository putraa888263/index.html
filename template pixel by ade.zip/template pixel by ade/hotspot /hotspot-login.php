:global doLogin do={
    :if ([:len $user] > 0) do={
        /ip hotspot active login user=$user password=$password
    } else={
        /ip hotspot active login user=$voucher
    }
}

:if ([:len $username] > 0) do={
    :set $user $username
    :set $password $password
    $doLogin
} else={
    :if ([:len $voucher] > 0) do={
        :set $voucher $voucher
        $doLogin
    }
}