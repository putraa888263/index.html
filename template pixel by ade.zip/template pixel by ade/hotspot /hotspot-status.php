:if ($status == "connected") do={
    :put "<html><body><h1>Welcome $(username)!</h1><p>You are connected.</p></body></html>"
} else={
    :put "<html><body><h1>Error</h1><p>$(error)</p></body></html>"
}